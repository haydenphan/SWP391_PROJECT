package model.google;

public class Constants {
	public static String GOOGLE_CLIENT_ID = "263891916042-n6kt44kv15issl4b028jfd166lpdbica.apps.googleusercontent.com";
	public static String GOOGLE_CLIENT_SECRET = "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";
	public static String GOOGLE_REDIRECT_URI = "http://localhost:8080/LoginVia/login";
	public static String GOOGLE_LINK_GET_TOKEN = "https://accounts.google.com/o/oauth2/token";
	public static String GOOGLE_LINK_GET_USER_INFO = "https://www.googleapis.com/oauth2/v1/userinfo?access_token=";
	public static String GOOGLE_GRANT_TYPE = "authorization_code";
}
