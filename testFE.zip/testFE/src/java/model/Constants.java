package model;

public class Constants {
    public static String GOOGLE_CLIENT_ID = "151505397859-gras04bfo18abfhbguik5cqtgaaleaqs.apps.googleusercontent.com";
    public static String GOOGLE_CLIENT_SECRET = "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";
    public static String GOOGLE_REDIRECT_URI = "http://localhost:8080/testFE/loginByGG";
    public static String GOOGLE_LINK_GET_TOKEN = "https://oauth2.googleapis.com/token";
    public static String GOOGLE_LINK_GET_USER_INFO = "https://www.googleapis.com/oauth2/v1/userinfo?access_token=";
    public static String GOOGLE_GRANT_TYPE = "authorization_code";
}
